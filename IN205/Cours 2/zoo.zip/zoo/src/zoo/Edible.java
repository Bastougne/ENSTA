package zoo;

public interface Edible {

}
