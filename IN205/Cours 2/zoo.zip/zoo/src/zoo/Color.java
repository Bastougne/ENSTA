package zoo;

public enum Color {
	ORANGE, GREEN, BLACK, PINK, WHITE
}
