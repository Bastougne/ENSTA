package zoo;

public abstract class Animal implements CanEat, Edible {
	private int nbLegs;
	private Color color;
	private static int nbAnimals;

	public Animal(int nbLegs, Color color) {
		this.nbLegs = nbLegs;
		this.color = color;
		nbAnimals += 1;
	}

	public int getNbLegs() {
		return nbLegs;
	}

	public Color getColor() {
		return color;
	}

	public static int getNbAnimals() {
		return nbAnimals;
	}

	@Override
	public String toString() {
		return "an " + this.getColor().name().toLowerCase() + " " + this.getClass().getSimpleName() + " with " + this.getNbLegs() + " legs";
	}
}
