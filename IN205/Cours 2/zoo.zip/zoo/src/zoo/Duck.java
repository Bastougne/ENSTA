package zoo;

public class Duck extends Bird {

	public Duck() {
		this(2, Color.GREEN);
	}
	
	public Duck(int nbLegs, Color color) {
		super(nbLegs, color);
	}
}
