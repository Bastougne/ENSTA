package zoo;

public abstract class Bird extends Animal implements CanFly {

	public Bird(int i, Color c) {
		super(i, c);
	}

	public void eat(Edible edible) {
		if (edible instanceof Seed) {
			System.out.println("the " + this.getClass().getSimpleName() + " eat a " + edible.getClass().getSimpleName());
		} else {
			System.out.println("the " + this.getClass().getSimpleName() + " does not eat a " + edible.getClass().getSimpleName());
		}
	}
}
