package zoo;

public interface CanEat {
	public void eat(Edible e);
}
