package zoo;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Cat cat = new Cat(4, Color.ORANGE);
		Bird duck = new Duck(2, Color.GREEN);
		Ostrich ostrich = new Ostrich(2, Color.WHITE);

		cat.eat(new Seed());
		cat.eat(duck);
		cat.eat(ostrich);

		Cage<Animal> cage = new Cage<>(duck);
		cage.setContent(cat);
		Zoo zoo = new Zoo();
		zoo.createCage(cage);
		zoo.createCage(new Cage<Animal>(duck));
		zoo.createCage(new Cage<Animal>(ostrich));
		System.out.println(zoo);

		List<CanFly> canFlyList = new ArrayList<>();
		canFlyList.add(ostrich);
		canFlyList.add(duck);
		for (CanFly canFly : canFlyList) {
			String toPrint = "the " + canFly.getClass().getSimpleName();
			toPrint += canFly.canFly() ? " can fly" : " can't fly";
			System.out.println(toPrint);
		}
	}

}
