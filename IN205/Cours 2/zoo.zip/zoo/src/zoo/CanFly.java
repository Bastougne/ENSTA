package zoo;

public interface CanFly {
	public default boolean canFly() {
		return true;
	}
}
