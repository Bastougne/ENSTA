package zoo;

public class Cat extends Animal {

	public Cat(int nbLegs, Color color) {
		super(nbLegs, color);
	}

	public void eat(Edible edible) {
		if (edible instanceof Bird) {
			System.out.println("the " + this.getClass().getSimpleName() + " eat a " + edible.getClass().getSimpleName());
		} else {
			System.out.println("the " + this.getClass().getSimpleName() + " does not eat a " + edible.getClass().getSimpleName());
		}
	}
}
