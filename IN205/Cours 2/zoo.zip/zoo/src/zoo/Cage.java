package zoo;

public class Cage <T> {
	private T content;
	
	public Cage(T content) {
		this.content = content;
	}

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}
	
	@Override
	public String toString() {
		return "[" + content + "]";
	}
}
