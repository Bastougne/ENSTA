package zoo;
import java.util.ArrayList;
import java.util.List;

public class Zoo {
	private List<Cage<Animal>> cages;
	
	public Zoo() {
		this.cages = new ArrayList<Cage<Animal>>();
	}

	public List<Cage<Animal>> getCages() {
		return cages;
	}

	public void createCage(Cage<Animal> cage) {
		cages.add(cage);
	}

	@Override
	public String toString() {
		String string = "this zoo contains :";
		for (Cage<Animal> cage : cages) {
			string += "\n  " + cage;
		}
		return string;
	}
	
}
