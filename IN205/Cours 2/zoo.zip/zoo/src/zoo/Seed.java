package zoo;

public class Seed implements Edible {

}
