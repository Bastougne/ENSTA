package zoo;

public class Ostrich extends Bird {

	public Ostrich(int nbLegs, Color color) {
		super(nbLegs, color);
	}

	@Override
	public boolean canFly() {
		return false;
	}
}
